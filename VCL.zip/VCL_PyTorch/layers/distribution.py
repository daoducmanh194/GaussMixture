import math
import torch
from torch.nn import functional


class GaussMixture(torch.nn.Module):
    """
    Class for build Gauss Mixture Posterior Variational
    """

    def __init__(self, list_mu, list_rho, list_coff, device):
        super(GaussMixture, self).__init__()
        self.mu = list_mu.to(device)
        self.rho = list_rho.to(device)
        self.coff = list_coff.to(device)
        self.device = device
        self.normal = torch.distributions.Normal(0, 1)
        self.uniform = torch.distributions.Uniform(0, 1)
        self.sigma = torch.log1p(torch.exp(self.rho)).to(device)
        self.coff = torch.nn.functional.softmax(self.alpha, dim=0)
        self.tau = 100.0
        print("Tau: ", self.tau)

    def sample_gauss(self):
        epsilon = self.normal.sample(self.rho.size()).to(self.device)
        posterior_sample = (self.mu + self.sigma * epsilon).to(self.device)
        return posterior_sample

    def sample_gumbel_softmax(self):
        e = 1.e-10
        uniform_sample = self.uniform.sample(self.coff.size()) + e
        gumbel_sample = -torch.log(-torch.log(uniform_sample)).to(self.device)
        gumbel_softmax = torch.nn.functional.softmax(1. / self.tau * (torch.log(self.coff) + gumbel_sample), dim=0)
        return gumbel_softmax

    def sample(self):
        # sample from mixture distribution by gumbel softmax
        gumbel_softmax = self.sample_gumbel_softmax()
        gauss_sample = self.sample_gauss()
        return torch.sum(torch.mul(gumbel_softmax, gauss_sample), dim=0)

    def sample_test(self):
        gumbel_softmax = self.sample_gumbel_softmax()
        return torch.sum(torch.mul(gumbel_softmax, self.mu), dim=0)

    def prob_gauss(self, input, mu, sigma):
        return 1. / (sigma * math.sqrt(2 * math.pi)) * torch.exp(-1. / 2 * ((input - mu) / sigma) ** 2)

    def log_prob(self, input):
        result = 0.
        num_component = len(self.mu)
        for i in range(num_component):
            result += self.coff[i] * self.prob_gauss(input, self.mu[i], self.sigma[i])
        return torch.log(result).sum()
