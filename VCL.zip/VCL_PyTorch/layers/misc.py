import torch
from torch import nn
from torch.nn import functional


class FlattenLayer(nn.Module):

    def __init__(self, num_features):
        super().__init__()
        self.num_features = num_features

    def forward(self, x):
        return x.view(-1, self.num_features)


def KL_DIV(mu_p, sig_p, mu_q, sig_q):
    kl = 0.5 * (2 * torch.log(sig_p / sig_q) - 1 + (sig_q / sig_p).pow(2) + ((mu_p - mu_q) / sig_p).pow(2)).sum()
    return kl


def upperbound_kl_divergence_mixture_gauss(mix_gauss_1, mix_gauss_2):
    number_component = len(mix_gauss_1[0])
    list_coff_1 = torch.Tensor(mix_gauss_1[2])
    list_coff_2 = torch.Tensor(mix_gauss_2[2])
    list_mean_1 = mix_gauss_1[0]
    list_mean_2 = mix_gauss_2[0]
    list_log_variance_1 = mix_gauss_1[1]
    list_variance_2 = mix_gauss_2[1]
    list_coff_1 = torch.nn.functional.softmax(list_coff_1, dim=0)
    list_coff_2 = torch.nn.functional.softmax(list_coff_2, dim=0)
    kl = 0.
    heso = compute_alpha(number_component)
    for i in range(number_component):
        kl += torch.sum(list_coff_1[i] * (torch.log(list_coff_1[i]) - torch.log(list_coff_2[i])))
        kl += torch.sum(
            list_coff_1[i] * kl_gauss(list_mean_1[i], list_log_variance_1[i], list_mean_2[i], list_variance_2[i]))
    return kl


def kl_gauss(means_1, log_variance_1, means_2, variance_2):
    kl = 0.
    kl += 0.5 * (torch.log(variance_2) - log_variance_1) + 0.5 * (
            torch.exp(log_variance_1) + (means_1 - means_2) ** 2) / variance_2 - 0.5
    return kl


def compute_alpha(num_component):
    result = []
    result.append(1)
    for i in range(num_component - 1):
        result.append((i + 1) * 10000)
    result = result[::-1]
    return result
