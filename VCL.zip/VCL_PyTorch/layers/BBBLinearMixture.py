import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Parameter
from distribution import GaussMixture
from misc import upperbound_kl_divergence_mixture_gauss


class BBBLinearMixture(nn.Module):
    """
    Build Bayesian Linear Mixture Layer
    """

    def __init__(self, in_features, out_features, bias=True, priors=None, gauss_mixture=1):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.use_bias = bias
        self.gauss_mixture = gauss_mixture
        device = 'cuda:0'
        self.device = device

        # list for store current bias, weight
        self.list_W_mu = []
        self.list_W_rho = []
        self.list_W_coff = []
        self.list_b_mu = []
        self.list_b_rho = []
        self.list_b_coff = []

        # list for store priors
        self.list_prior_W_mu = []
        self.list_prior_W_sigma = []
        self.list_prior_W_coff = []
        self.list_prior_b_mu = []
        self.list_prior_b_sigma = []
        self.list_prior_b_coff = []

        self.log_prior = 0
        self.log_variational_posterior = 0

        for mixture in range(self.gauss_mixture):
            if priors is None:
                priors = {
                    'prior_mu': 0,
                    'prior_sigma': 0.01,
                    'prior_coff': 0.0
                }
            self.prior_W_mu = torch.Tensor(priors['prior_mu'])
            self.prior_W_sigma = torch.Tensor(priors['prior_sigma'])
            self.prior_W_coff = torch.Tensor(priors['prior_coff'])
            self.list_prior_W_mu.append(self.prior_W_mu)
            self.list_prior_W_sigma.append(self.prior_W_sigma)
            self.list_prior_W_coff.append(self.prior_W_coff)

            self.prior_bias_mu = torch.Tensor(priors['prior_mu'])
            self.prior_bias_sigma = torch.Tensor(priors['prior_sigma'])
            self.prior_bias_coff = torch.Tensor(priors['prior_coff'])
            self.list_prior_b_mu.append(self.prior_bias_mu)
            self.list_prior_b_sigma.append(self.prior_bias_sigma)
            self.list_prior_b_coff.append(self.prior_bias_coff)

            self.W_mu = Parameter(torch.Tensor(out_features, in_features))
            self.W_rho = Parameter(torch.Tensor(out_features, in_features))
            self.W_coff = Parameter(torch.Tensor(out_features, in_features))
            self.list_W_mu.append(self.W_mu)
            self.list_W_rho.append(self.W_rho)
            self.list_W_coff.append(self.W_coff)
            if self.use_bias:
                self.bias_mu = Parameter(torch.Tensor(out_features))
                self.bias_rho = Parameter(torch.Tensor(out_features))
                self.bias_coff = Parameter(torch.Tensor(out_features))
                self.list_b_mu.append(self.bias_mu)
                self.list_b_rho.append(self.bias_rho)
                self.list_b_coff.append(self.bias_coff)
            else:
                self.register_parameter('bias_mu', None)
                self.register_parameter('bias_rho', None)
                self.register_parameter('bias_coff', None)
                self.list_b_mu.append(self.bias_mu)
                self.list_b_rho.append(self.bias_rho)
                self.list_b_coff.append(self.bias_coff)

            self.reset_parameters()

        self.weight = GaussMixture(self.list_W_mu, self.list_W_rho, self.list_W_coff, self.device)
        if self.use_bias:
            self.bias = GaussMixture(self.list_b_mu, self.list_b_rho, self.list_b_coff, self.device)
        else:
            self.register_parameter('bias', None)

    def reset_parameters(self):
        self.W_mu.data.normal_(0, 0.1)
        self.W_rho.data.fill_(-3)
        self.W_coff.data.fill_(0.0)

        if self.use_bias:
            self.bias_mu.data.normal_(0, 0.1)
            self.bias_rho.data.fill_(-3)
            self.bias_coff.fill_(0.0)

    """
    def forward(self, x, sample=True):
        act_W = []  # actual list of weight [w1, w2, .., wn] for each Gauss
        for mixture in self.gauss_mixture:
            self.W_sigma = torch.log1p(torch.exp(self.W_rho))
            if self.use_bias:
                self.bias_sigma = torch.log1p(torch.exp(self.bias_rho))
                bias_var = self.bias_sigma ** 2

            act_mu = F.linear(x, self.W_mu, self.bias_mu)
            act_var = 1e-16 + F.linear(x ** 2, self.W_sigma ** 2, bias_var)
            act_std = torch.sqrt(act_var)

            if self.training or sample:
                eps = torch.empty(act_mu.size()).normal_(0, 1).to(act_mu.device)
                act_W.append(act_mu + act_std * eps)
            else:
                act_W.append(act_mu)
        return act_W
    """

    def forward(self, x, sample=False, calculate_log_probs=False):
        if self.training or sample:
            weight = self.weight.sample()
            bias = self.bias.sample() if self.use_bias else None
        else:
            print("Sample test")
            weight = self.weight.sample_test()
            bias = self.bias.sample_test()
            print("self.training ", self.training, calculate_log_probs)

        if self.training or calculate_log_probs:
            # trong luc feed forward thi tinh luon log posterior
            if self.use_bias:
                self.log_prior = self.weight_prior.log_prob(weight) + self.bias_prior.log_prob(bias)
                self.log_variational_posterior = self.weight.log_prob(weight) + self.bias.log_prob(bias)
            else:
                self.log_prior = self.weight_prior.log_prob(weight)
                self.log_variational_posterior = self.weight.log_prob(weight)
        else:
            self.log_prior, self.log_variational_posterior = 0, 0
            print("Log Prior ", self.log_prior)
            print("Log Variational Posterior: ", self.log_variational_posterior)

        return F.linear(x, weight, bias)

    def kl_loss(self):
        kl = 0
        # kl weights
        mixture1 = [self.list_W_mu, torch.log1p(torch.exp(self.W_rho)), self.list_W_coff]
        prior_mu = np.array(self.list_prior_W_mu, dtype=np.float32)
        prior_sigma = np.array(self.list_prior_W_sigma, dtype=np.float32)
        prior_coff = np.array(self.list_prior_W_coff, dtype=np.float32)
        mixture2 = [prior_mu, prior_sigma, prior_coff]
        kl += upperbound_kl_divergence_mixture_gauss(mixture1, mixture2)

        # kl cho bias
        mixture1 = [self.list_b_mu, torch.log1p(torch.exp(self.b_rho)), self.list_b_coff]
        prior_mu = np.array(self.list_prior_b_mu, dtype=np.float32)
        prior_sigma = np.array(self.list_prior_b_sigma, dtype=np.float32)
        prior_coff = np.array(self.list_prior_b_coff, dtype=np.float32)
        mixture2 = [prior_mu, prior_sigma, prior_coff]
        kl += upperbound_kl_divergence_mixture_gauss(mixture1, mixture2)

        return kl
