import torch
import torch.nn as nn
import torch.nn.functional as F
from layers import BBBLinearMixture, BBBConvMIxture


class Cifar10ModelMixture(nn.Module):

    def __init__(self):
        """
        input: 3x32x32
        output: 1 classifiers with 10 nodes
        """
        super(Cifar10ModelMixture, self).__init__()
        self.conv1 = BBBConvMIxture(in_channels=3, out_channels=6, kernel_size=5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = BBBConvMIxture(in_channels=6, out_channels=16, kernel_size=5)
        self.fc1 = BBBLinearMixture(in_features=16 * 5 * 5, out_features=120)
        self.fc2 = BBBLinearMixture(in_features=120, out_features=84)
        self.fc3 = BBBLinearMixture(in_features=84, out_features=10)

    def forward(self, x, task_id):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

    def get_kl(self, task_id):
        kl = 0.0
        kl += self.conv1.kl_loss()
        kl += self.conv2.kl_loss()
        kl += self.fc1.kl_loss()
        kl += self.fc2.kl_loss()
        kl += self.fc3.kl_loss()
        return kl

    def update_prior(self):
        self.conv1.list_prior_W_mu = self.conv1.list_W_mu.data
        self.conv1.list_prior_W_sigma = self.conv1.list_W_sigma.data
        if self.conv1.use_bias:
            self.conv1.list_prior_bias_mu = self.conv1.list_bias_mu.data
            self.conv1.list_prior_bias_sigma = self.conv1.list_bias_sigma.data

        self.conv2.list_prior_W_mu = self.conv2.list_W_mu.data
        self.conv2.list_prior_W_sigma = self.conv2.list_W_sigma.data
        if self.conv2.use_bias:
            self.conv2.list_prior_bias_mu = self.conv2.list_bias_mu.data
            self.conv2.list_prior_bias_sigma = self.conv2.list_bias_sigma.data

        self.fc1.list_prior_W_mu = self.fc1.list_W_mu.data
        self.fc1.list_prior_W_sigma = self.fc1.list_W_sigma.data
        if self.fc1.use_bias:
            self.fc1.list_prior_bias_mu = self.fc1.list_bias_mu.data
            self.fc1.list_prior_bias_sigma = self.fc1.list_bias_sigma.data

        self.fc2.list_prior_W_mu = self.fc2.list_W_mu.data
        self.fc2.list_prior_W_sigma = self.fc2.list_W_sigma.data
        if self.fc2.use_bias:
            self.fc2.list_prior_bias_mu = self.fc2.list_bias_mu.data
            self.fc2.list_prior_bias_sigma = self.fc2.list_bias_sigma.data

        self.fc3.list_prior_W_mu = self.fc3.list_W_mu.data
        self.fc3.list_prior_W_sigma = self.fc3.list_W_sigma.data
        if self.fc3.use_bias:
            self.fc3.list_prior_bias_mu = self.fc3.lsit_bias_mu.data
            self.fc3.list_prior_bias_sigma = self.fc3.list_bias_sigma.data
