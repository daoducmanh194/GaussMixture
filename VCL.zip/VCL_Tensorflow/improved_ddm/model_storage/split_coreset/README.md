Store model weights here (for multi-head split MNIST, with coresets).
