Store model weights here (for multi-head split MNIST, no coresets).
