Store model weights here (for permuted MNIST, no coresets).
