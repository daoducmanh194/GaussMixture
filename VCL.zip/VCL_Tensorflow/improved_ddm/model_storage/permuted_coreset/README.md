Store model weights here (for permuted MNIST, with coresets).
